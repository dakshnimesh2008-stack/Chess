package com.chessarena.game

import com.chessarena.game.chess.*
import org.junit.Assert.*
import org.junit.Test

class ChessRulesTest {
    private fun perft(p: Position, d: Int): Long {
        if (d == 0) return 1
        var n = 0L
        for (m in p.legalMoves()) n += perft(p.make(m), d - 1)
        return n
    }
    private fun mv(g: ChessGame, uci: String): Boolean {
        val m = g.pos.legalMoves().firstOrNull { it.uci() == uci } ?: return false
        return g.play(m)
    }

    @Test fun perftStart() { val p = Position.start(); assertEquals(20L, perft(p, 1)); assertEquals(400L, perft(p, 2)); assertEquals(8902L, perft(p, 3)) }
    @Test fun perftKiwipete() {
        val p = Position.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1")
        assertEquals(48L, perft(p, 1)); assertEquals(2039L, perft(p, 2))
    }
    @Test fun perftPromotionsPosition() {
        val p = Position.fromFen("n1n5/PPPk4/8/8/8/8/4Kppp/5N1N b - - 0 1")
        assertEquals(24L, perft(p, 1)); assertEquals(496L, perft(p, 2))
    }
    @Test fun enPassant() {
        val g = ChessGame(); for (m in listOf("e2e4", "a7a6", "e4e5", "d7d5")) assertTrue(mv(g, m))
        assertTrue(mv(g, "e5d6")); assertEquals(PAWN, 1); assertEquals(0, g.pos.b[3 + 4 * 8]) // d5 empty after capture
        assertEquals("exd6", g.sans.last())
    }
    @Test fun castlingBothSides() {
        val p = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        val ms = p.legalMoves().map { it.uci() }
        assertTrue("e1g1" in ms); assertTrue("e1c1" in ms)
        assertEquals("O-O", p.san(p.legalMoves().first { it.uci() == "e1g1" }))
        assertEquals("O-O-O", p.san(p.legalMoves().first { it.uci() == "e1c1" }))
    }
    @Test fun noCastlingThroughCheck() {
        val p = Position.fromFen("4k3/8/8/8/8/5r2/8/R3K2R w KQ - 0 1")
        assertFalse("e1g1" in p.legalMoves().map { it.uci() }); assertTrue("e1c1" in p.legalMoves().map { it.uci() })
    }
    @Test fun promotionHasFourChoices() {
        val p = Position.fromFen("7k/4P3/8/8/8/8/8/4K3 w - - 0 1")
        assertEquals(4, p.legalMoves().count { it.from == 52 && it.to == 60 })
        assertEquals("e8=Q+", p.san(p.legalMoves().first { it.uci() == "e7e8q" }))
    }
    @Test fun foolsMate() {
        val g = ChessGame(); for (m in listOf("f2f3", "e7e5", "g2g4", "d8h4")) assertTrue(mv(g, m))
        assertEquals(Outcome.CHECKMATE, g.status()); assertEquals("Qh4#", g.sans.last())
    }
    @Test fun stalemate() { val g = ChessGame(Position.fromFen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")); assertEquals(Outcome.STALEMATE, g.status()) }
    @Test fun insufficientMaterial() {
        assertEquals(Outcome.INSUFFICIENT, ChessGame(Position.fromFen("8/8/8/4k3/8/8/3K4/8 w - - 0 1")).status())
        assertEquals(Outcome.INSUFFICIENT, ChessGame(Position.fromFen("8/8/8/4k3/8/8/3KB3/8 w - - 0 1")).status())
        assertEquals(Outcome.ONGOING, ChessGame(Position.fromFen("8/8/8/4k3/8/8/3KP3/8 w - - 0 1")).status())
    }
    @Test fun threefoldRepetition() {
        val g = ChessGame(); val cycle = listOf("g1f3", "g8f6", "f3g1", "f6g8")
        repeat(2) { for (m in cycle) assertTrue(mv(g, m)) }
        assertEquals(Outcome.THREEFOLD, g.status())
    }
    @Test fun fiftyMoveRule() { assertEquals(Outcome.FIFTY, ChessGame(Position.fromFen("4k3/8/8/8/8/8/8/R3K3 w - - 100 80")).status()) }
    @Test fun sanDisambiguation() {
        val p = Position.fromFen("4k3/8/8/8/8/8/8/R3K2R w - - 0 1")
        assertEquals("Rad1", p.san(p.legalMoves().first { it.uci() == "a1d1" }))
    }
    @Test fun undoRestoresPosition() {
        val g = ChessGame(); val f = g.pos.fen(); mv(g, "e2e4"); assertTrue(g.undo()); assertEquals(f, g.pos.fen())
    }
    @Test fun illegalMoveRejected() { val g = ChessGame(); assertFalse(mv(g, "e2e5")); assertEquals(0, g.moves.size) }
    @Test fun engineFindsMateInOne() {
        val p = Position.fromFen("6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1")
        assertEquals("a1a8", SearchEngine().bestMove(p, emptyList(), Difficulty.MEDIUM)?.uci())
    }
    @Test fun engineReturnsLegalMoveAtEveryLevel() {
        for (d in listOf(Difficulty.BEGINNER, Difficulty.EASY, Difficulty.MEDIUM)) {
            val p = Position.start(); val m = SearchEngine().bestMove(p, emptyList(), d)!!
            assertTrue(p.legalMoves().any { it == m })
        }
    }
    @Test fun fenRoundTrip() { assertEquals(Position.START, Position.start().fen()) }
}
