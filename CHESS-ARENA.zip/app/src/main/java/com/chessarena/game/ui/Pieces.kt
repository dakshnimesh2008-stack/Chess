package com.chessarena.game.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import com.chessarena.game.chess.*

private fun poly(vararg v: Float): Path = Path().apply {
    moveTo(v[0], v[1]); var i = 2; while (i < v.size) { lineTo(v[i], v[i + 1]); i += 2 }; close()
}
private fun circ(cx: Float, cy: Float, r: Float): Path = Path().apply { addOval(Rect(cx - r, cy - r, cx + r, cy + r)) }
private fun oval(l: Float, t: Float, r: Float, b: Float): Path = Path().apply { addOval(Rect(l, t, r, b)) }
private fun rrect(l: Float, t: Float, r: Float, b: Float, rad: Float): Path = Path().apply { addRoundRect(RoundRect(l, t, r, b, CornerRadius(rad, rad))) }
private fun union(vararg p: Path): Path { var a = p[0]; for (i in 1 until p.size) a = Path.combine(PathOperation.Union, a, p[i]); return a }

private class Shape(val body: Path, val detail: Path? = null)

private val base by lazy { union(rrect(20f, 79f, 80f, 91f, 4f), poly(28f, 80f, 33f, 70f, 67f, 70f, 72f, 80f)) }

private val shapes: Map<Int, Shape> by lazy {
    mapOf(
        PAWN to Shape(union(circ(50f, 29f, 12f), poly(41f, 38f, 59f, 38f, 63f, 58f, 70f, 72f, 30f, 72f, 37f, 58f), base)),
        ROOK to Shape(union(poly(30f, 14f, 30f, 34f, 36f, 40f, 34f, 72f, 66f, 72f, 64f, 40f, 70f, 34f, 70f, 14f, 62f, 14f, 62f, 23f, 56f, 23f, 56f, 14f, 44f, 14f, 44f, 23f, 38f, 23f, 38f, 14f), base),
            Path().apply { moveTo(35f, 36f); lineTo(65f, 36f) }),
        BISHOP to Shape(union(oval(38f, 18f, 62f, 50f), circ(50f, 15f, 5f), poly(42f, 46f, 58f, 46f, 65f, 72f, 35f, 72f, 40f, 58f), base),
            Path().apply { moveTo(46f, 26f); lineTo(55f, 38f) }),
        QUEEN to Shape(union(poly(27f, 26f, 36f, 54f, 41f, 24f, 50f, 52f, 59f, 24f, 64f, 54f, 73f, 26f, 68f, 68f, 32f, 68f),
            poly(33f, 66f, 67f, 66f, 72f, 75f, 28f, 75f), circ(27f, 23f, 4.5f), circ(41f, 19f, 4.5f), circ(59f, 19f, 4.5f), circ(73f, 23f, 4.5f), circ(50f, 15f, 5f), base),
            Path().apply { moveTo(34f, 62f); lineTo(66f, 62f) }),
        KING to Shape(union(poly(39f, 34f, 61f, 34f, 67f, 58f, 71f, 72f, 29f, 72f, 33f, 58f), oval(35f, 26f, 65f, 48f),
            poly(46f, 6f, 54f, 6f, 54f, 13f, 61f, 13f, 61f, 21f, 54f, 21f, 54f, 30f, 46f, 30f, 46f, 21f, 39f, 21f, 39f, 13f, 46f, 13f), base),
            Path().apply { moveTo(35f, 56f); lineTo(65f, 56f) }),
        KNIGHT to Shape(union(poly(28f, 72f, 33f, 54f, 29f, 47f, 37f, 34f, 34f, 27f, 42f, 23f, 44f, 12f, 52f, 20f, 63f, 24f, 71f, 42f, 72f, 60f, 71f, 72f), base),
            Path().apply { addOval(Rect(46f, 28f, 51f, 33f)) })
    )
}

fun DrawScope.drawPiece(type: Int, white: Boolean, style: Int, x: Float, y: Float, size: Float) {
    val st = PieceStyles[style.coerceIn(0, PieceStyles.lastIndex)]
    val sh = shapes[type] ?: return
    val top = if (white) st.wTop else st.bTop; val bot = if (white) st.wBot else st.bBot; val line = if (white) st.wLine else st.bLine
    translate(x, y) {
        scale(size / 100f, pivot = Offset.Zero) {
            translate(1.5f, 2.5f) { drawPath(sh.body, Color.Black.copy(alpha = 0.28f)) }
            drawPath(sh.body, Brush.verticalGradient(listOf(top, bot), startY = 8f, endY = 92f))
            drawPath(sh.body, line, style = Stroke(width = 2.2f, join = StrokeJoin.Round))
            sh.detail?.let { d ->
                if (type == KNIGHT) drawPath(d, line) else drawPath(d, line, style = Stroke(width = 2f, cap = StrokeCap.Round))
            }
        }
    }
}
