package com.chessarena.game.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import com.chessarena.game.chess.*
import kotlin.math.abs

@Composable
fun BoardView(
    pos: Position, modifier: Modifier = Modifier, flipped: Boolean = false, boardTheme: Int = 0, pieceTheme: Int = 0,
    coords: Boolean = true, selected: Int = -1, targets: Set<Int> = emptySet(), lastMove: Move? = null, showHints: Boolean = true,
    animMs: Int = 180, onTap: (Int) -> Unit = {}
) {
    val bc = BoardThemes[boardTheme.coerceIn(0, BoardThemes.lastIndex)]
    val tm = rememberTextMeasurer()
    val progress = remember { Animatable(1f) }
    LaunchedEffect(lastMove, pos) {
        if (lastMove != null && animMs > 0) { progress.snapTo(0f); progress.animateTo(1f, tween(animMs)) } else progress.snapTo(1f)
    }
    val checkSq = if (pos.inCheck()) pos.kingSq(pos.white) else -1
    fun col(f: Int) = if (flipped) 7 - f else f
    fun row(r: Int) = if (flipped) r else 7 - r

    Canvas(modifier.aspectRatio(1f).pointerInput(flipped) {
        detectTapGestures { o ->
            val s = size.width / 8f
            val c = (o.x / s).toInt().coerceIn(0, 7); val rw = (o.y / s).toInt().coerceIn(0, 7)
            val f = if (flipped) 7 - c else c; val r = if (flipped) rw else 7 - rw
            onTap(r * 8 + f)
        }
    }) {
        val s = size.width / 8f
        for (sq in 0 until 64) {
            val f = sq and 7; val r = sq shr 3
            val x = col(f) * s; val y = row(r) * s
            val light = (f + r) % 2 == 1
            drawRect(if (light) bc.light else bc.dark, Offset(x, y), Size(s, s))
            if (lastMove != null && (sq == lastMove.from || sq == lastMove.to)) drawRect(Color(0x66F1D77A), Offset(x, y), Size(s, s))
            if (sq == checkSq) drawRect(Color(0x99E53935), Offset(x, y), Size(s, s))
            if (sq == selected) drawRect(Color(0x884FC3F7), Offset(x, y), Size(s, s))
        }
        if (coords) for (i in 0..7) {
            val fileSq = i; val rankSq = i * 8
            val cF = if ((i + 0) % 2 == 1) bc.dark else bc.light
            val cR = if ((i + 7) % 2 == 1) bc.dark else bc.light
            drawText(tm, "${'a' + i}", Offset(col(i) * s + s * 0.08f, (if (flipped) 0 else 7) * s + s * 0.72f), TextStyle(color = cF.copy(alpha = 0.9f), fontSize = (s / 4.2f / density * 1f).sp))
            drawText(tm, "${i + 1}", Offset((if (flipped) 7 else 0) * s + s * 0.06f, row(i) * s + s * 0.04f), TextStyle(color = cR.copy(alpha = 0.9f), fontSize = (s / 4.2f / density * 1f).sp))
        }
        // pieces
        var moving = -1
        for (sq in 0 until 64) {
            val p = pos.b[sq]; if (p == 0) continue
            if (lastMove != null && sq == lastMove.to && progress.value < 1f) { moving = sq; continue }
            drawPiece(abs(p), p > 0, pieceTheme, col(sq and 7) * s + s * 0.06f, row(sq shr 3) * s + s * 0.06f, s * 0.88f)
        }
        if (moving >= 0 && lastMove != null) {
            val p = pos.b[moving]; val t = 1f - progress.value
            val dx = (col(lastMove.from and 7) - col(lastMove.to and 7)) * s * t
            val dy = (row(lastMove.from shr 3) - row(lastMove.to shr 3)) * s * t
            drawPiece(abs(p), p > 0, pieceTheme, col(moving and 7) * s + s * 0.06f + dx, row(moving shr 3) * s + s * 0.06f + dy, s * 0.88f)
        }
        if (showHints) for (t in targets) {
            val x = col(t and 7) * s; val y = row(t shr 3) * s
            if (pos.b[t] != 0) drawCircle(Color(0x99D32F2F), s * 0.46f, Offset(x + s / 2, y + s / 2), style = Stroke(s * 0.09f))
            else drawCircle(Color(0x88000000), s * 0.14f, Offset(x + s / 2, y + s / 2))
        }
    }
}
