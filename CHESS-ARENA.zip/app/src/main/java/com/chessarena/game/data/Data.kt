package com.chessarena.game.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// ---------- Room ----------
@Entity(tableName = "games")
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val mode: String,          // "COMPUTER" or "LOCAL"
    val difficulty: String,    // difficulty label or "-"
    val result: String,        // "WIN", "LOSS", "DRAW" (from player's view; LOCAL: "WHITE","BLACK","DRAW")
    val reason: String,
    val playerWhite: Boolean,
    val moveCount: Int,
    val durationSec: Int,
    val uci: String,           // space separated UCI moves for replay
    val sanText: String
)

@Dao
interface GameDao {
    @Insert suspend fun insert(g: GameEntity): Long
    @Query("SELECT * FROM games ORDER BY date DESC") fun all(): Flow<List<GameEntity>>
    @Query("SELECT * FROM games WHERE id = :id") suspend fun byId(id: Long): GameEntity?
    @Query("DELETE FROM games") suspend fun clear()
}

@Database(entities = [GameEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun games(): GameDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "chessarena.db").build().also { inst = it }
        }
    }
}

// ---------- DataStore settings ----------
private val Context.store by preferencesDataStore("settings")

data class Settings(
    val dark: Boolean = true,
    val boardTheme: Int = 0,
    val pieceTheme: Int = 0,
    val sound: Boolean = true,
    val vibration: Boolean = true,
    val animSpeed: Int = 1,        // 0 slow, 1 normal, 2 fast
    val reducedMotion: Boolean = false,
    val coordinates: Boolean = true,
    val legalHints: Boolean = true,
    val confirmResign: Boolean = true,
    val confirmRestart: Boolean = true,
    val clockMinutes: Int = 0,     // 0 = no clock
    val clockIncrement: Int = 0,
    val language: String = "English"
)

class SettingsRepo(private val ctx: Context) {
    private object K {
        val dark = booleanPreferencesKey("dark"); val board = intPreferencesKey("board"); val piece = intPreferencesKey("piece")
        val sound = booleanPreferencesKey("sound"); val vib = booleanPreferencesKey("vib"); val anim = intPreferencesKey("anim")
        val reduced = booleanPreferencesKey("reduced"); val coords = booleanPreferencesKey("coords"); val hints = booleanPreferencesKey("hints")
        val cResign = booleanPreferencesKey("cresign"); val cRestart = booleanPreferencesKey("crestart")
        val clock = intPreferencesKey("clock"); val inc = intPreferencesKey("inc"); val lang = stringPreferencesKey("lang")
    }
    val flow: Flow<Settings> = ctx.store.data.map { p ->
        val d = Settings()
        Settings(p[K.dark] ?: d.dark, p[K.board] ?: d.boardTheme, p[K.piece] ?: d.pieceTheme, p[K.sound] ?: d.sound,
            p[K.vib] ?: d.vibration, p[K.anim] ?: d.animSpeed, p[K.reduced] ?: d.reducedMotion, p[K.coords] ?: d.coordinates,
            p[K.hints] ?: d.legalHints, p[K.cResign] ?: d.confirmResign, p[K.cRestart] ?: d.confirmRestart,
            p[K.clock] ?: d.clockMinutes, p[K.inc] ?: d.clockIncrement, p[K.lang] ?: d.language)
    }
    suspend fun save(s: Settings) {
        ctx.store.edit {
            it[K.dark] = s.dark; it[K.board] = s.boardTheme; it[K.piece] = s.pieceTheme; it[K.sound] = s.sound; it[K.vib] = s.vibration
            it[K.anim] = s.animSpeed; it[K.reduced] = s.reducedMotion; it[K.coords] = s.coordinates; it[K.hints] = s.legalHints
            it[K.cResign] = s.confirmResign; it[K.cRestart] = s.confirmRestart; it[K.clock] = s.clockMinutes; it[K.inc] = s.clockIncrement
            it[K.lang] = s.language
        }
    }
}
