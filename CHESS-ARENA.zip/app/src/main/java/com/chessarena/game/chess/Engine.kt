package com.chessarena.game.chess

import kotlin.math.abs
import kotlin.random.Random

enum class Difficulty(val label: String, val rating: Int, val depth: Int, val timeMs: Long, val noise: Int) {
    BEGINNER("Beginner", 400, 1, 300, 140),
    EASY("Easy", 800, 2, 500, 60),
    MEDIUM("Medium", 1200, 3, 1000, 20),
    HARD("Hard", 1600, 4, 1500, 0),
    EXPERT("Expert", 1900, 6, 3000, 0),
    MASTER("Master", 2200, 8, 5000, 0)
}

/**
 * Built-in alpha-beta search engine (negamax, iterative deepening, quiescence, MVV-LVA ordering,
 * transposition-free). NOT Stockfish: bundling Stockfish requires native binaries (see README).
 * The [Engine] interface keeps it swappable for a UCI Stockfish wrapper.
 */
interface Engine { fun bestMove(pos: Position, history: List<String>, d: Difficulty): Move? }

class SearchEngine : Engine {
    private val VAL = intArrayOf(0, 100, 320, 330, 500, 900, 0)
    private var deadline = 0L
    private var aborted = false
    @Volatile var cancelled = false

    private fun eval(p: Position): Int { // from side-to-move view
        var score = 0; var queens = 0
        for (i in 0 until 64) { val v = p.b[i]; if (v == 0) continue
            val t = abs(v); val f = i and 7; val r = i shr 3
            val rr = if (v > 0) r else 7 - r
            val center = 3 - minOf(abs(f - 3), abs(f - 4)).coerceAtMost(3) // 0..3
            val cr = 3 - minOf(abs(r - 3), abs(r - 4)).coerceAtMost(3)
            var s = VAL[t]
            when (t) {
                PAWN -> s += rr * 6 + center * 4 + (if (rr >= 5) rr * 8 else 0)
                KNIGHT -> s += (center + cr) * 9 - (if (rr == 0) 15 else 0)
                BISHOP -> s += (center + cr) * 5 - (if (rr == 0) 10 else 0)
                ROOK -> s += (if (rr == 6) 20 else 0)
                QUEEN -> { queens++; s += (center + cr) * 2 }
                KING -> s += if (rr == 0 && (f <= 2 || f >= 6)) 25 else if (rr == 0) 5 else -rr * 6
            }
            score += if (v > 0) s else -s
        }
        return if (p.white) score else -score
    }

    private fun order(p: Position, ms: List<Move>): List<Move> = ms.sortedByDescending {
        var sc = 0
        val victim = abs(p.b[it.to]); if (victim != 0) sc += 10 * VAL[victim] - VAL[abs(p.b[it.from])]
        if (it.promo != 0) sc += VAL[it.promo]
        sc
    }

    private fun timeUp(): Boolean { if (cancelled || System.currentTimeMillis() > deadline) aborted = true; return aborted }

    private fun quiesce(p: Position, alphaIn: Int, beta: Int, ply: Int): Int {
        var alpha = alphaIn
        val stand = eval(p)
        if (stand >= beta) return stand
        if (stand > alpha) alpha = stand
        if (ply > 6 || timeUp()) return stand
        for (m in order(p, p.legalCaptures())) {
            val s = -quiesce(p.make(m), -beta, -alpha, ply + 1)
            if (aborted) return alpha
            if (s >= beta) return s
            if (s > alpha) alpha = s
        }
        return alpha
    }

    private fun negamax(p: Position, depth: Int, alphaIn: Int, beta: Int, ply: Int): Int {
        var alpha = alphaIn
        val ms = p.legalMoves()
        if (ms.isEmpty()) return if (p.inCheck()) -100000 + ply else 0
        if (p.insufficientMaterial() || p.half >= 100) return 0
        if (depth <= 0) return quiesce(p, alpha, beta, 0)
        if (timeUp()) return 0
        var best = -1000000
        for (m in order(p, ms)) {
            val s = -negamax(p.make(m), depth - 1, -beta, -alpha, ply + 1)
            if (aborted) return best
            if (s > best) best = s
            if (s > alpha) alpha = s
            if (alpha >= beta) break
        }
        return best
    }

    override fun bestMove(pos: Position, history: List<String>, d: Difficulty): Move? {
        cancelled = false; aborted = false
        val root = pos.legalMoves()
        if (root.isEmpty()) return null
        if (root.size == 1) return root[0]
        deadline = System.currentTimeMillis() + d.timeMs
        var best = root[0]
        var scored: List<Pair<Move, Int>> = root.map { it to 0 }
        for (depth in 1..d.depth) {
            aborted = false
            val cur = ArrayList<Pair<Move, Int>>()
            var alpha = -1000000
            val ordered = if (depth == 1) order(pos, root) else scored.sortedByDescending { it.second }.map { it.first }
            for (m in ordered) {
                val s = -negamax(pos.make(m), depth - 1, -1000000, -alpha + 1, 1) + (if (d.noise > 0) Random.nextInt(-d.noise, d.noise + 1) else 0)
                if (aborted) break
                cur.add(m to s)
                if (s > alpha) alpha = s
            }
            if (aborted) { if (cur.isNotEmpty() && depth > 1) { /* discard partial iteration */ }; break }
            scored = cur; best = cur.maxByOrNull { it.second }!!.first
            if (alpha > 90000) break
        }
        return best
    }
}
