package com.chessarena.game.chess

import kotlin.math.abs

/** Piece encoding: +1..+6 white (P,N,B,R,Q,K), -1..-6 black. 0 = empty. Square = rank*8+file, a1 = 0. */
const val PAWN = 1; const val KNIGHT = 2; const val BISHOP = 3; const val ROOK = 4; const val QUEEN = 5; const val KING = 6

data class Move(val from: Int, val to: Int, val promo: Int = 0) {
    fun uci(): String = sqName(from) + sqName(to) + when (promo) { KNIGHT -> "n"; BISHOP -> "b"; ROOK -> "r"; QUEEN -> "q"; else -> "" }
}

fun sqName(s: Int) = "${'a' + (s and 7)}${'1' + (s shr 3)}"

private val KN = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(2, -1), intArrayOf(1, -2), intArrayOf(-1, -2), intArrayOf(-2, -1), intArrayOf(-2, 1), intArrayOf(-1, 2))
private val DIAG = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))
private val ORTH = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))

class Position(
    val b: IntArray, val white: Boolean, val castle: Int, val ep: Int, val half: Int, val full: Int
) {
    companion object {
        const val START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        fun start() = fromFen(START)
        fun fromFen(fen: String): Position {
            val p = fen.trim().split(" ")
            val b = IntArray(64)
            var rank = 7; var file = 0
            for (c in p[0]) {
                when {
                    c == '/' -> { rank--; file = 0 }
                    c.isDigit() -> file += c.digitToInt()
                    else -> {
                        val t = when (c.lowercaseChar()) { 'p' -> PAWN; 'n' -> KNIGHT; 'b' -> BISHOP; 'r' -> ROOK; 'q' -> QUEEN; else -> KING }
                        b[rank * 8 + file] = if (c.isUpperCase()) t else -t; file++
                    }
                }
            }
            var cs = 0
            val cr = p.getOrElse(2) { "-" }
            if ('K' in cr) cs = cs or 1; if ('Q' in cr) cs = cs or 2; if ('k' in cr) cs = cs or 4; if ('q' in cr) cs = cs or 8
            val e = p.getOrElse(3) { "-" }
            val ep = if (e == "-") -1 else (e[0] - 'a') + (e[1] - '1') * 8
            return Position(b, p.getOrElse(1) { "w" } == "w", cs, ep, p.getOrElse(4) { "0" }.toInt(), p.getOrElse(5) { "1" }.toInt())
        }
    }

    private fun own(p: Int) = if (white) p > 0 else p < 0

    fun kingSq(w: Boolean): Int { val k = if (w) KING else -KING; for (i in 0 until 64) if (b[i] == k) return i; return -1 }

    fun attacked(sq: Int, byWhite: Boolean): Boolean {
        val f = sq and 7; val r = sq shr 3
        val s = if (byWhite) 1 else -1
        // pawns
        val pr = r - s
        if (pr in 0..7) for (df in intArrayOf(-1, 1)) { val pf = f + df; if (pf in 0..7 && b[pr * 8 + pf] == s * PAWN) return true }
        for (d in KN) { val nf = f + d[0]; val nr = r + d[1]; if (nf in 0..7 && nr in 0..7 && b[nr * 8 + nf] == s * KNIGHT) return true }
        for (dr in -1..1) for (df in -1..1) { if (dr == 0 && df == 0) continue; val nf = f + df; val nr = r + dr; if (nf in 0..7 && nr in 0..7 && b[nr * 8 + nf] == s * KING) return true }
        for (d in DIAG) { var nf = f + d[0]; var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) { val p = b[nr * 8 + nf]; if (p != 0) { if (p == s * BISHOP || p == s * QUEEN) return true; break }; nf += d[0]; nr += d[1] } }
        for (d in ORTH) { var nf = f + d[0]; var nr = r + d[1]
            while (nf in 0..7 && nr in 0..7) { val p = b[nr * 8 + nf]; if (p != 0) { if (p == s * ROOK || p == s * QUEEN) return true; break }; nf += d[0]; nr += d[1] } }
        return false
    }

    fun inCheck(w: Boolean = white): Boolean { val k = kingSq(w); return k >= 0 && attacked(k, !w) }

    private fun pseudo(): ArrayList<Move> {
        val out = ArrayList<Move>(48)
        val s = if (white) 1 else -1
        for (sq in 0 until 64) {
            val p = b[sq]; if (p == 0 || !own(p)) continue
            val f = sq and 7; val r = sq shr 3
            when (abs(p)) {
                PAWN -> {
                    val nr = r + s
                    if (nr !in 0..7) continue
                    val promoRank = nr == 7 || nr == 0
                    fun add(to: Int) { if (promoRank) for (pp in intArrayOf(QUEEN, ROOK, BISHOP, KNIGHT)) out.add(Move(sq, to, pp)) else out.add(Move(sq, to)) }
                    if (b[nr * 8 + f] == 0) {
                        add(nr * 8 + f)
                        val start = if (white) 1 else 6
                        if (r == start && b[(r + 2 * s) * 8 + f] == 0) out.add(Move(sq, (r + 2 * s) * 8 + f))
                    }
                    for (df in intArrayOf(-1, 1)) {
                        val nf = f + df; if (nf !in 0..7) continue
                        val t = nr * 8 + nf
                        if (b[t] != 0 && !own(b[t])) add(t) else if (t == ep && b[t] == 0) out.add(Move(sq, t))
                    }
                }
                KNIGHT -> for (d in KN) { val nf = f + d[0]; val nr = r + d[1]; if (nf in 0..7 && nr in 0..7) { val t = nr * 8 + nf; if (b[t] == 0 || !own(b[t])) out.add(Move(sq, t)) } }
                KING -> {
                    for (dr in -1..1) for (df in -1..1) { if (dr == 0 && df == 0) continue; val nf = f + df; val nr = r + dr
                        if (nf in 0..7 && nr in 0..7) { val t = nr * 8 + nf; if (b[t] == 0 || !own(b[t])) out.add(Move(sq, t)) } }
                    val home = if (white) 4 else 60
                    if (sq == home && !attacked(sq, !white)) {
                        val ks = if (white) 1 else 4; val qs = if (white) 2 else 8
                        val rook = s * ROOK
                        if (castle and ks != 0 && b[home + 3] == rook && b[home + 1] == 0 && b[home + 2] == 0 &&
                            !attacked(home + 1, !white) && !attacked(home + 2, !white)) out.add(Move(sq, home + 2))
                        if (castle and qs != 0 && b[home - 4] == rook && b[home - 1] == 0 && b[home - 2] == 0 && b[home - 3] == 0 &&
                            !attacked(home - 1, !white) && !attacked(home - 2, !white)) out.add(Move(sq, home - 2))
                    }
                }
                else -> {
                    val dirs = when (abs(p)) { BISHOP -> DIAG.toList(); ROOK -> ORTH.toList(); else -> DIAG.toList() + ORTH.toList() }
                    for (d in dirs) { var nf = f + d[0]; var nr = r + d[1]
                        while (nf in 0..7 && nr in 0..7) { val t = nr * 8 + nf
                            if (b[t] == 0) out.add(Move(sq, t)) else { if (!own(b[t])) out.add(Move(sq, t)); break }
                            nf += d[0]; nr += d[1] } }
                }
            }
        }
        return out
    }

    fun make(m: Move): Position {
        val nb = b.copyOf()
        val p = nb[m.from]; val t = abs(p)
        val capture = nb[m.to] != 0
        var nep = -1
        nb[m.to] = if (m.promo != 0) (if (p > 0) m.promo else -m.promo) else p
        nb[m.from] = 0
        if (t == PAWN) {
            if (m.to == ep && !capture && (m.from and 7) != (m.to and 7)) nb[m.to + (if (p > 0) -8 else 8)] = 0
            if (abs(m.to - m.from) == 16) nep = (m.from + m.to) / 2
        }
        if (t == KING && abs(m.to - m.from) == 2) {
            if (m.to > m.from) { nb[m.from + 1] = nb[m.from + 3]; nb[m.from + 3] = 0 } else { nb[m.from - 1] = nb[m.from - 4]; nb[m.from - 4] = 0 }
        }
        var cs = castle
        if (m.from == 4 || m.to == 4) cs = cs and 3.inv()
        if (m.from == 60 || m.to == 60) cs = cs and 12.inv()
        if (m.from == 0 || m.to == 0) cs = cs and 2.inv()
        if (m.from == 7 || m.to == 7) cs = cs and 1.inv()
        if (m.from == 56 || m.to == 56) cs = cs and 8.inv()
        if (m.from == 63 || m.to == 63) cs = cs and 4.inv()
        return Position(nb, !white, cs, nep, if (t == PAWN || capture) 0 else half + 1, if (white) full else full + 1)
    }

    fun legalMoves(): List<Move> {
        val res = ArrayList<Move>(40)
        for (m in pseudo()) { val n = make(m); if (!n.inCheck(white)) res.add(m) }
        return res
    }

    /** Legal moves for the pseudo list but only captures/promotions (for quiescence). */
    fun legalCaptures(): List<Move> = legalMoves().filter { b[it.to] != 0 || it.promo != 0 || (abs(b[it.from]) == PAWN && it.to == ep) }

    fun isCapture(m: Move) = b[m.to] != 0 || (abs(b[m.from]) == PAWN && (m.from and 7) != (m.to and 7))

    fun key(): String {
        val sb = StringBuilder(80)
        for (v in b) sb.append((v + 6).toChar())
        sb.append(if (white) 'w' else 'b').append(castle.toChar())
        // en-passant counts only if an enemy pawn could pseudo-capture
        var epk = -1
        if (ep >= 0) {
            val s = if (white) 1 else -1
            val f = ep and 7; val r = (ep shr 3) - s
            for (df in intArrayOf(-1, 1)) { val nf = f + df; if (nf in 0..7 && r in 0..7 && b[r * 8 + nf] == s * PAWN) epk = ep }
        }
        sb.append(epk)
        return sb.toString()
    }

    fun insufficientMaterial(): Boolean {
        val minors = ArrayList<Int>() // squares of bishops, plus knight markers
        var bishopsOnly = true; var count = 0
        val bishopColors = HashSet<Int>()
        for (i in 0 until 64) {
            val t = abs(b[i]); if (t == 0 || t == KING) continue
            if (t == PAWN || t == ROOK || t == QUEEN) return false
            count++
            if (t == KNIGHT) bishopsOnly = false else bishopColors.add(((i shr 3) + (i and 7)) and 1)
        }
        if (count == 0) return true
        if (count == 1) return true
        return bishopsOnly && bishopColors.size == 1
    }

    fun fen(): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var e = 0
            for (f in 0..7) { val p = b[r * 8 + f]
                if (p == 0) e++ else { if (e > 0) { sb.append(e); e = 0 }
                    val c = "pnbrqk"[abs(p) - 1]; sb.append(if (p > 0) c.uppercaseChar() else c) } }
            if (e > 0) sb.append(e); if (r > 0) sb.append('/')
        }
        sb.append(if (white) " w " else " b ")
        val c = (if (castle and 1 != 0) "K" else "") + (if (castle and 2 != 0) "Q" else "") + (if (castle and 4 != 0) "k" else "") + (if (castle and 8 != 0) "q" else "")
        sb.append(if (c.isEmpty()) "-" else c).append(' ').append(if (ep < 0) "-" else sqName(ep)).append(' ').append(half).append(' ').append(full)
        return sb.toString()
    }

    /** Standard Algebraic Notation of [m] (must be legal in this position). */
    fun san(m: Move): String {
        val p = b[m.from]; val t = abs(p)
        val sb = StringBuilder()
        if (t == KING && abs(m.to - m.from) == 2) sb.append(if (m.to > m.from) "O-O" else "O-O-O")
        else {
            val cap = isCapture(m)
            if (t == PAWN) {
                if (cap) sb.append('a' + (m.from and 7)).append('x')
            } else {
                sb.append("PNBRQK"[t - 1])
                val others = legalMoves().filter { it.to == m.to && it.from != m.from && abs(b[it.from]) == t }
                if (others.isNotEmpty()) {
                    val sameFile = others.any { (it.from and 7) == (m.from and 7) }
                    val sameRank = others.any { (it.from shr 3) == (m.from shr 3) }
                    if (!sameFile) sb.append('a' + (m.from and 7))
                    else if (!sameRank) sb.append('1' + (m.from shr 3))
                    else sb.append(sqName(m.from))
                }
                if (cap) sb.append('x')
            }
            sb.append(sqName(m.to))
            if (m.promo != 0) sb.append('=').append("PNBRQK"[m.promo - 1])
        }
        val n = make(m)
        if (n.inCheck()) sb.append(if (n.legalMoves().isEmpty()) '#' else '+')
        return sb.toString()
    }
}

enum class Outcome { ONGOING, CHECKMATE, STALEMATE, INSUFFICIENT, THREEFOLD, FIFTY, FIVEFOLD, SEVENTYFIVE, TIMEOUT, RESIGN, AGREED_DRAW }

/** A running game: positions, moves, SAN list and captures with undo support. */
class ChessGame(start: Position = Position.start()) {
    val positions = arrayListOf(start)
    val moves = arrayListOf<Move>()
    val sans = arrayListOf<String>()
    val captured = arrayListOf<Int>() // piece captured at each ply (0 if none)

    val pos get() = positions.last()
    val lastMove get() = moves.lastOrNull()

    fun legalFrom(sq: Int) = pos.legalMoves().filter { it.from == sq }

    fun play(m: Move): Boolean {
        val legal = pos.legalMoves().firstOrNull { it.from == m.from && it.to == m.to && it.promo == m.promo } ?: return false
        val cur = pos
        sans.add(cur.san(legal))
        val cp = if (cur.ep == legal.to && abs(cur.b[legal.from]) == PAWN && cur.b[legal.to] == 0) (if (cur.white) -PAWN else PAWN) else cur.b[legal.to]
        captured.add(cp)
        moves.add(legal)
        positions.add(cur.make(legal))
        return true
    }

    fun undo(): Boolean {
        if (moves.isEmpty()) return false
        moves.removeAt(moves.size - 1); sans.removeAt(sans.size - 1); captured.removeAt(captured.size - 1); positions.removeAt(positions.size - 1)
        return true
    }

    private fun repetitions(): Int { val k = pos.key(); return positions.count { it.key() == k } }

    fun status(): Outcome {
        val p = pos
        val legal = p.legalMoves()
        if (legal.isEmpty()) return if (p.inCheck()) Outcome.CHECKMATE else Outcome.STALEMATE
        if (p.insufficientMaterial()) return Outcome.INSUFFICIENT
        val rep = repetitions()
        if (rep >= 5) return Outcome.FIVEFOLD
        if (p.half >= 150) return Outcome.SEVENTYFIVE
        if (rep >= 3) return Outcome.THREEFOLD
        if (p.half >= 100) return Outcome.FIFTY
        return Outcome.ONGOING
    }
}
