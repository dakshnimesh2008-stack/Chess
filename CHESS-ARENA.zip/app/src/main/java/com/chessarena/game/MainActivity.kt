package com.chessarena.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.chessarena.game.ui.*

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val s by vm.settings.collectAsState()
            ChessTheme(s.dark) {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    BackHandler(enabled = vm.stack.size > 1) { vm.back() }
                    when (val sc = vm.screen) {
                        Screen.Home -> HomeScreen(vm)
                        Screen.Setup -> SetupScreen(vm)
                        Screen.Game -> GameScreen(vm)
                        Screen.History -> HistoryScreen(vm)
                        is Screen.Detail -> DetailScreen(vm, sc.id)
                        Screen.Stats -> StatsScreen(vm)
                        Screen.Settings -> SettingsScreen(vm)
                        Screen.Learn -> LearnScreen(vm)
                        Screen.About -> AboutScreen(vm)
                    }
                }
            }
        }
    }

    override fun onStop() { vm.onPause(); super.onStop() }
    override fun onStart() { super.onStart(); vm.onResume() }
}
