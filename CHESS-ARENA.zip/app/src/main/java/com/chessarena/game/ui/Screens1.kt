package com.chessarena.game.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessarena.game.AppViewModel
import com.chessarena.game.Mode
import com.chessarena.game.R
import com.chessarena.game.Screen
import com.chessarena.game.chess.*
import kotlin.math.abs

@Composable
fun HomeScreen(vm: AppViewModel) {
    val s = vm.settings.collectAsState().value
    val appear = remember { Animatable(if (s.reducedMotion) 1f else 0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(700)) }
    val ongoing = vm.version >= 0 && vm.game.moves.isNotEmpty() && !vm.over
    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp).alpha(appear.value),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.logo_badge), null, Modifier.size(120.dp).scale(0.8f + 0.2f * appear.value))
        Text("CHESS ARENA", fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
        Text("Think. Move. Conquer.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth(0.72f).clip(RoundedCornerShape(10.dp)).border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))) {
            BoardView(Position.start(), boardTheme = s.boardTheme, pieceTheme = s.pieceTheme, coords = false, animMs = 0)
        }
        Spacer(Modifier.height(18.dp))
        if (ongoing) { GoldButton("Continue Game", Modifier.fillMaxWidth()) { vm.go(Screen.Game) }; Spacer(Modifier.height(10.dp)) }
        GoldButton("Play vs Computer", Modifier.fillMaxWidth()) { vm.pendingMode = Mode.COMPUTER; vm.go(Screen.Setup) }
        Spacer(Modifier.height(10.dp))
        OutlineButton("Local Multiplayer", Modifier.fillMaxWidth()) { vm.pendingMode = Mode.LOCAL; vm.go(Screen.Setup) }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton("History", Modifier.weight(1f)) { vm.go(Screen.History) }
            OutlineButton("Statistics", Modifier.weight(1f)) { vm.go(Screen.Stats) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton("Chess Rules", Modifier.weight(1f)) { vm.go(Screen.Learn) }
            OutlineButton("Settings", Modifier.weight(1f)) { vm.go(Screen.Settings) }
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = { vm.go(Screen.About) }) { Text("About", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> Chips(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primary, selectedLabelColor = MaterialTheme.colorScheme.onPrimary))
        }
    }
}

@Composable
fun SetupScreen(vm: AppViewModel) {
    val st = vm.settings.collectAsState().value
    var mode by remember { mutableStateOf(vm.pendingMode) }
    var color by remember { mutableStateOf("White") }
    var diff by remember { mutableStateOf(Difficulty.MEDIUM) }
    var minutes by remember { mutableIntStateOf(st.clockMinutes) }
    var inc by remember { mutableIntStateOf(st.clockIncrement) }
    var custom by remember { mutableStateOf(false) }
    var customText by remember { mutableStateOf("") }
    Frame(if (mode == Mode.COMPUTER) "Play vs Computer" else "Local Multiplayer", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
            SectionTitle("MODE")
            Chips(listOf(Mode.COMPUTER, Mode.LOCAL), mode, { if (it == Mode.COMPUTER) "Vs Computer" else "Local (2 players)" }) { mode = it }
            if (mode == Mode.COMPUTER) {
                SectionTitle("YOUR COLOR")
                Chips(listOf("White", "Black", "Random"), color, { it }) { color = it }
                SectionTitle("DIFFICULTY")
                Chips(Difficulty.values().toList(), diff, { "${it.label} (${it.rating})" }) { diff = it }
            }
            SectionTitle("TIME CONTROL (MINUTES)")
            Chips(listOf(0, 1, 3, 5, 10, 15, 30, -1), if (custom) -1 else minutes, { when (it) { 0 -> "No clock"; -1 -> "Custom"; else -> "$it min" } }) {
                if (it == -1) custom = true else { custom = false; minutes = it }
            }
            if (custom) {
                OutlinedTextField(customText, { t -> customText = t.filter { c -> c.isDigit() }.take(3); minutes = customText.toIntOrNull()?.coerceIn(1, 180) ?: 0 },
                    label = { Text("Minutes per side (1-180)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            if (minutes > 0) {
                SectionTitle("INCREMENT (SECONDS)")
                Chips(listOf(0, 1, 2, 3, 5, 10), inc, { "+$it s" }) { inc = it }
            }
            Spacer(Modifier.height(24.dp))
            GoldButton("Start Game", Modifier.fillMaxWidth(), enabled = !(custom && minutes == 0)) {
                val white = when (color) { "White" -> true; "Black" -> false; else -> kotlin.random.Random.nextBoolean() }
                vm.startGame(mode, white, diff, minutes, if (minutes > 0) inc else 0)
                vm.stack.removeAt(vm.stack.size - 1); vm.go(Screen.Game)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun fmt(ms: Long): String {
    val t = ms.coerceAtLeast(0)
    if (t < 10_000) return "%d.%d".format(t / 1000, (t % 1000) / 100)
    val s = t / 1000; return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun PlayerBar(name: String, sub: String, white: Boolean, active: Boolean, clock: String?, captured: List<Int>, adv: Int, style: Int, thinking: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(if (white) Color(0xFFF3E9CC) else Color(0xFF26262C)).border(2.dp, if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape),
            contentAlignment = Alignment.Center) { PieceIcon(KING, white, style, 28.dp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                if (thinking) { Spacer(Modifier.width(8.dp)); CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sub, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(6.dp))
                captured.sortedBy { abs(it) }.forEach { PieceIcon(abs(it), it > 0, style, 14.dp) }
                if (adv > 0) Text(" +${adv / 100}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
            }
        }
        if (clock != null) Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text(clock, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun GameScreen(vm: AppViewModel) {
    val st = vm.settings.collectAsState().value
    val ver = vm.version // observe
    val g = vm.game; val pos = g.pos
    var confirm by remember { mutableStateOf<String?>(null) }
    val animMs = if (st.reducedMotion) 0 else when (st.animSpeed) { 0 -> 320; 1 -> 180; else -> 90 }
    val vals = intArrayOf(0, 100, 320, 330, 500, 900, 0)
    fun matVal(list: List<Int>) = list.sumOf { vals[abs(it)] }
    val capByWhite = g.captured.filterIndexed { i, c -> i % 2 == 0 && c != 0 }
    val capByBlack = g.captured.filterIndexed { i, c -> i % 2 == 1 && c != 0 }
    val advWhite = matVal(capByWhite) - matVal(capByBlack)
    val topWhite = vm.flipped // white on top when board flipped
    fun bar(white: Boolean): @Composable () -> Unit = {
        val computer = vm.mode == Mode.COMPUTER
        val isEngine = computer && white == vm.engineWhite
        val name = if (computer) (if (isEngine) "Computer" else "You") else if (white) "White" else "Black"
        val sub = if (isEngine) "${vm.difficulty.label} · ~${vm.difficulty.rating}" else if (computer) "Player" else "Player ${if (white) 1 else 2}"
        val cap = if (white) capByWhite else capByBlack
        val adv = if (white) advWhite else -advWhite
        PlayerBar(name, sub, white, !vm.over && pos.white == white, if (vm.clockEnabled) fmt(if (white) vm.whiteMs else vm.blackMs) else null,
            cap, adv, st.pieceTheme, vm.thinking && isEngine)
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.back() }) { Text("← Menu", color = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.weight(1f))
            val status = when {
                vm.over -> "Game over"
                pos.inCheck() -> "${if (pos.white) "White" else "Black"} is in check!"
                else -> "${if (pos.white) "White" else "Black"} to move"
            }
            Text(status, fontWeight = FontWeight.SemiBold, color = if (pos.inCheck()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.width(8.dp))
        }
        bar(topWhite)()
        BoardView(pos, Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(6.dp)),
            flipped = vm.flipped, boardTheme = st.boardTheme, pieceTheme = st.pieceTheme, coords = st.coordinates, selected = vm.selected,
            targets = vm.targets.map { it.to }.toSet(), lastMove = g.lastMove, showHints = st.legalHints, animMs = animMs, onTap = { vm.tap(it) })
        bar(!topWhite)()
        // move history
        val ls = rememberLazyListState()
        LaunchedEffect(g.sans.size) { if (g.sans.isNotEmpty()) ls.animateScrollToItem(g.sans.size - 1) }
        LazyRow(state = ls, modifier = Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(g.sans) { i, san ->
                Text(if (i % 2 == 0) "${i / 2 + 1}. $san" else san, fontSize = 14.sp, fontWeight = if (i == g.sans.size - 1) FontWeight.Bold else FontWeight.Normal,
                    color = if (i == g.sans.size - 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            val m = Modifier.weight(1f)
            TextButton(onClick = { vm.undo() }, modifier = m, enabled = g.moves.isNotEmpty()) { Text("Undo", fontSize = 12.sp) }
            TextButton(onClick = { vm.flipped = !vm.flipped }, modifier = m) { Text("Flip", fontSize = 12.sp) }
            TextButton(onClick = { if (st.confirmRestart && g.moves.isNotEmpty() && !vm.over) confirm = "restart" else vm.restart() }, modifier = m) { Text("Restart", fontSize = 12.sp) }
            TextButton(onClick = { confirm = "draw" }, modifier = m, enabled = !vm.over && g.moves.isNotEmpty()) { Text("Draw", fontSize = 12.sp) }
            TextButton(onClick = { if (st.confirmResign) confirm = "resign" else vm.resign() }, modifier = m, enabled = !vm.over && g.moves.isNotEmpty()) { Text("Resign", fontSize = 12.sp) }
            TextButton(onClick = { vm.go(Screen.Settings) }, modifier = m) { Text("Settings", fontSize = 12.sp) }
        }
    }
    // dialogs
    vm.promoChoices?.let {
        AlertDialog(onDismissRequest = { vm.cancelPromotion() }, confirmButton = {}, title = { Text("Promote pawn to") }, text = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (p in intArrayOf(QUEEN, ROOK, BISHOP, KNIGHT)) Box(Modifier.size(60.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable { vm.choosePromotion(p) }, contentAlignment = Alignment.Center) {
                    PieceIcon(p, pos.white, st.pieceTheme, 46.dp)
                }
            }
        })
    }
    confirm?.let { c ->
        val (title, text) = when (c) { "resign" -> "Resign?" to "You will lose this game."; "restart" -> "Restart?" to "The current game will be discarded.";
            else -> "Offer a draw?" to (if (vm.mode == Mode.LOCAL) "Hand the device to your opponent. Do they accept the draw?" else "The computer will decide whether to accept.") }
        AlertDialog(onDismissRequest = { confirm = null }, title = { Text(title) }, text = { Text(text) },
            confirmButton = { TextButton(onClick = { when (c) { "resign" -> vm.resign(); "restart" -> vm.restart(); else -> vm.offerDraw() }; confirm = null }) { Text(if (c == "draw") (if (vm.mode == Mode.LOCAL) "Opponent accepts" else "Offer") else "Yes") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } })
    }
    vm.message?.let { m -> AlertDialog(onDismissRequest = { vm.message = null }, confirmButton = { TextButton(onClick = { vm.message = null }) { Text("OK") } }, text = { Text(m) }) }
    vm.engineError?.let { m -> AlertDialog(onDismissRequest = { vm.engineError = null }, confirmButton = { TextButton(onClick = { vm.engineError = null; vm.home() }) { Text("Home") } },
        title = { Text("Engine problem") }, text = { Text(m) }) }
    if (vm.showResult && vm.over) ResultDialog(vm)
}

@Composable
fun ResultDialog(vm: AppViewModel) {
    val w = vm.winnerWhite
    val computer = vm.mode == Mode.COMPUTER
    val title = when {
        w == null -> "Draw"
        computer -> if (w == vm.playerWhite) "Victory!" else "Defeat"
        else -> if (w) "White wins!" else "Black wins!"
    }
    val reason = when (vm.outcome) {
        Outcome.CHECKMATE -> "Checkmate"; Outcome.STALEMATE -> "Stalemate"; Outcome.INSUFFICIENT -> "Draw by insufficient material"
        Outcome.THREEFOLD -> "Draw by threefold repetition"; Outcome.FIFTY -> "Draw by the fifty-move rule"
        Outcome.FIVEFOLD -> "Draw by fivefold repetition"; Outcome.SEVENTYFIVE -> "Draw by the seventy-five-move rule"
        Outcome.TIMEOUT -> if (w == null) "Time out (opponent cannot mate): draw" else "Win on time"
        Outcome.RESIGN -> "Resignation"; Outcome.AGREED_DRAW -> "Draw by agreement"; else -> ""
    }
    val pulse = rememberInfiniteTransition(label = "r")
    val sc by pulse.animateFloat(1f, 1.08f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
    AlertDialog(onDismissRequest = { vm.showResult = false }, confirmButton = {
        TextButton(onClick = { vm.rematch() }) { Text("Rematch") }
    }, dismissButton = {
        Row { TextButton(onClick = { vm.showResult = false }) { Text("Review") }; TextButton(onClick = { vm.home() }) { Text("Home") } }
    }, title = { Text(title, fontSize = 28.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, modifier = Modifier.scale(if (vm.settings.value.reducedMotion) 1f else sc)) },
        text = {
            Column {
                Text(reason, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Total moves: ${(vm.game.moves.size + 1) / 2}")
                Text("Duration: ${"%d:%02d".format(vm.durationSec / 60, vm.durationSec % 60)}")
            }
        })
}
