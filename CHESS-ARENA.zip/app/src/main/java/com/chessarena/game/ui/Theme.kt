package com.chessarena.game.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF1D77A)
val Charcoal = Color(0xFF16161A)
val Surface1 = Color(0xFF1E1E24)
val Black = Color(0xFF0B0B0D)

private val Dark = darkColorScheme(
    primary = Gold, onPrimary = Color.Black, secondary = GoldLight, onSecondary = Color.Black,
    background = Black, onBackground = Color(0xFFF2EEE3), surface = Surface1, onSurface = Color(0xFFF2EEE3),
    surfaceVariant = Color(0xFF2A2A32), onSurfaceVariant = Color(0xFFC9C3B3), outline = Color(0xFF5A5440),
    error = Color(0xFFE57373)
)
private val Light = lightColorScheme(
    primary = Color(0xFF8A6D1B), onPrimary = Color.White, secondary = Color(0xFFB08D2A),
    background = Color(0xFFFAF6EC), onBackground = Color(0xFF1B1A17), surface = Color.White, onSurface = Color(0xFF1B1A17),
    surfaceVariant = Color(0xFFEFE8D6), onSurfaceVariant = Color(0xFF4A463A), outline = Color(0xFF9A8F6B)
)

@Composable
fun ChessTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}

class BoardColors(val name: String, val light: Color, val dark: Color)
val BoardThemes = listOf(
    BoardColors("Classic Wooden", Color(0xFFF0D9B5), Color(0xFFB58863)),
    BoardColors("Marble", Color(0xFFE9E7E2), Color(0xFF8F9199)),
    BoardColors("Midnight", Color(0xFF8493B3), Color(0xFF2E3852)),
    BoardColors("Tournament", Color(0xFFEEEED2), Color(0xFF769656)),
    BoardColors("Emerald", Color(0xFFD7EBDD), Color(0xFF1F8A5F))
)

class PieceStyle(val name: String, val wTop: Color, val wBot: Color, val wLine: Color, val bTop: Color, val bBot: Color, val bLine: Color)
val PieceStyles = listOf(
    PieceStyle("Classic Ivory & Charcoal", Color(0xFFFFF8E6), Color(0xFFD9C79A), Color(0xFF3A3326), Color(0xFF5A5A62), Color(0xFF17171B), Color(0xFFE9E2CF)),
    PieceStyle("Gold & Onyx", Color(0xFFFBE38A), Color(0xFFC49A1E), Color(0xFF4A3A0A), Color(0xFF3B3B42), Color(0xFF050507), Color(0xFFD4AF37)),
    PieceStyle("Silver & Navy", Color(0xFFF4F6FA), Color(0xFFB4BCCB), Color(0xFF2A3345), Color(0xFF4C5E86), Color(0xFF16213D), Color(0xFFD7DEEE))
)
