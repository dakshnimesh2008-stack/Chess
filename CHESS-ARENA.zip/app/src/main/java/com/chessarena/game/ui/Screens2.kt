package com.chessarena.game.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chessarena.game.AppViewModel
import com.chessarena.game.R
import com.chessarena.game.Screen
import com.chessarena.game.chess.*
import com.chessarena.game.data.GameEntity
import java.text.DateFormat
import java.util.Date

private fun reasonText(r: String) = when (r) {
    "CHECKMATE" -> "Checkmate"; "STALEMATE" -> "Stalemate"; "INSUFFICIENT" -> "Insufficient material"; "THREEFOLD" -> "Threefold repetition"
    "FIFTY" -> "Fifty-move rule"; "FIVEFOLD" -> "Fivefold repetition"; "SEVENTYFIVE" -> "Seventy-five-move rule"; "TIMEOUT" -> "Timeout"
    "RESIGN" -> "Resignation"; "AGREED_DRAW" -> "Draw agreed"; else -> r
}

@Composable
fun HistoryScreen(vm: AppViewModel) {
    val games = vm.games.collectAsState().value
    var confirm by remember { mutableStateOf(false) }
    Frame("Game History", { vm.back() }) { pad ->
        if (games.isEmpty()) Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
            Text("No completed games yet.\nFinish a game and it will appear here.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(games) { g ->
                    val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(g.date))
                    Card(Modifier.fillMaxWidth().clickable { vm.go(Screen.Detail(g.id)) }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(14.dp)) {
                            Row { Text(resultLabel(g), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f)); Text(df, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Text("${if (g.mode == "COMPUTER") "vs Computer (${g.difficulty})" else "Local multiplayer"} · ${if (g.mode == "COMPUTER") (if (g.playerWhite) "White" else "Black") else "2 players"}", fontSize = 13.sp)
                            Text("${reasonText(g.reason)} · ${(g.moveCount + 1) / 2} moves · ${g.durationSec / 60}:${"%02d".format(g.durationSec % 60)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            TextButton(onClick = { confirm = true }) { Text("Clear history", color = MaterialTheme.colorScheme.error) }
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Clear all history?") }, text = { Text("This also resets your statistics.") },
        confirmButton = { TextButton(onClick = { vm.clearHistory(); confirm = false }) { Text("Clear") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })
}

private fun resultLabel(g: GameEntity) = when (g.result) { "WIN" -> "Victory"; "LOSS" -> "Defeat"; "DRAW" -> "Draw"; "WHITE" -> "White won"; "BLACK" -> "Black won"; else -> g.result }

@Composable
fun DetailScreen(vm: AppViewModel, id: Long) {
    val st = vm.settings.collectAsState().value
    val ent by produceState<GameEntity?>(null, id) { value = vm.gameById(id) }
    Frame("Review Game", { vm.back() }) { pad ->
        val g = ent
        if (g == null) { Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return@Frame }
        val game = remember(g) {
            try {
                val cg = ChessGame()
                if (g.uci.isNotBlank()) for (u in g.uci.split(" ")) {
                    val m = cg.pos.legalMoves().firstOrNull { it.uci() == u } ?: throw IllegalStateException("bad move $u")
                    cg.play(m)
                }
                cg
            } catch (e: Exception) { null }
        }
        if (game == null) { Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { Text("This saved game could not be loaded (invalid data).") }; return@Frame }
        var ply by remember(g) { mutableIntStateOf(game.moves.size) }
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            Text("${resultLabel(g)} · ${reasonText(g.reason)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            BoardView(game.positions[ply], Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)), flipped = g.mode == "COMPUTER" && !g.playerWhite, boardTheme = st.boardTheme,
                pieceTheme = st.pieceTheme, coords = st.coordinates, lastMove = if (ply > 0) game.moves[ply - 1] else null)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = { ply = 0 }, enabled = ply > 0) { Text("⏮") }
                TextButton(onClick = { ply-- }, enabled = ply > 0) { Text("◀") }
                Text("$ply / ${game.moves.size}", modifier = Modifier.align(Alignment.CenterVertically))
                TextButton(onClick = { ply++ }, enabled = ply < game.moves.size) { Text("▶") }
                TextButton(onClick = { ply = game.moves.size }, enabled = ply < game.moves.size) { Text("⏭") }
            }
            LazyColumn(Modifier.weight(1f)) {
                items((game.sans.size + 1) / 2) { i ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text("${i + 1}.", Modifier.width(36.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(game.sans[2 * i], Modifier.width(90.dp).clickable { ply = 2 * i + 1 }, fontWeight = if (ply == 2 * i + 1) FontWeight.Bold else FontWeight.Normal, color = if (ply == 2 * i + 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        if (2 * i + 1 < game.sans.size) Text(game.sans[2 * i + 1], Modifier.clickable { ply = 2 * i + 2 }, fontWeight = if (ply == 2 * i + 2) FontWeight.Bold else FontWeight.Normal, color = if (ply == 2 * i + 2) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCell(label: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun StatsScreen(vm: AppViewModel) {
    val games = vm.games.collectAsState().value
    val comp = games.filter { it.mode == "COMPUTER" }
    val wins = comp.count { it.result == "WIN" }; val losses = comp.count { it.result == "LOSS" }; val draws = games.count { it.result == "DRAW" }
    val whiteWins = games.count { (it.mode == "COMPUTER" && it.result == "WIN" && it.playerWhite) || (it.mode == "COMPUTER" && it.result == "LOSS" && !it.playerWhite) || it.result == "WHITE" }
    val blackWins = games.count { (it.mode == "COMPUTER" && it.result == "WIN" && !it.playerWhite) || (it.mode == "COMPUTER" && it.result == "LOSS" && it.playerWhite) || it.result == "BLACK" }
    var best = 0; var run = 0
    for (g in comp.sortedBy { it.date }) { if (g.result == "WIN") { run++; best = maxOf(best, run) } else run = 0 }
    val pct = if (comp.isEmpty()) "–" else "${wins * 100 / comp.size}%"
    Frame("Statistics", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCell("Total games", "${games.size}", Modifier.weight(1f)); StatCell("Win rate vs computer", pct, Modifier.weight(1f)) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCell("Wins", "$wins", Modifier.weight(1f)); StatCell("Losses", "$losses", Modifier.weight(1f)); StatCell("Draws", "$draws", Modifier.weight(1f)) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCell("White wins", "$whiteWins", Modifier.weight(1f)); StatCell("Black wins", "$blackWins", Modifier.weight(1f)) }
            StatCell("Best winning streak (vs computer)", "$best", Modifier.fillMaxWidth())
            Text("Wins, losses and win rate count games against the computer. Local games count toward totals, draws and White/Black wins.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings.collectAsState().value
    fun sw(label: String, v: Boolean, on: (Boolean) -> Unit): @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f)); Switch(v, on)
        }
    }
    Frame("Settings", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
            SectionTitle("APPEARANCE")
            sw("Dark theme", s.dark) { vm.updateSettings(s.copy(dark = it)) }()
            SectionTitle("BOARD THEME")
            Chips(BoardThemes.indices.toList(), s.boardTheme, { BoardThemes[it].name }) { vm.updateSettings(s.copy(boardTheme = it)) }
            SectionTitle("PIECE THEME")
            Chips(PieceStyles.indices.toList(), s.pieceTheme, { PieceStyles[it].name }) { vm.updateSettings(s.copy(pieceTheme = it)) }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth(0.6f).align(Alignment.CenterHorizontally).clip(RoundedCornerShape(8.dp))) {
                BoardView(Position.fromFen("r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4"), boardTheme = s.boardTheme, pieceTheme = s.pieceTheme, coords = s.coordinates, animMs = 0)
            }
            SectionTitle("GAMEPLAY")
            sw("Show board coordinates", s.coordinates) { vm.updateSettings(s.copy(coordinates = it)) }()
            sw("Highlight legal moves", s.legalHints) { vm.updateSettings(s.copy(legalHints = it)) }()
            sw("Confirm before resign", s.confirmResign) { vm.updateSettings(s.copy(confirmResign = it)) }()
            sw("Confirm before restart", s.confirmRestart) { vm.updateSettings(s.copy(confirmRestart = it)) }()
            SectionTitle("SOUND & MOTION")
            sw("Sound effects", s.sound) { vm.updateSettings(s.copy(sound = it)) }()
            sw("Vibration", s.vibration) { vm.updateSettings(s.copy(vibration = it)) }()
            sw("Reduced motion", s.reducedMotion) { vm.updateSettings(s.copy(reducedMotion = it)) }()
            Text("Animation speed", Modifier.padding(top = 8.dp))
            Chips(listOf(0, 1, 2), s.animSpeed, { listOf("Slow", "Normal", "Fast")[it] }) { vm.updateSettings(s.copy(animSpeed = it)) }
            SectionTitle("CHESS CLOCK DEFAULTS")
            Chips(listOf(0, 1, 3, 5, 10, 15, 30), s.clockMinutes, { if (it == 0) "No clock" else "$it min" }) { vm.updateSettings(s.copy(clockMinutes = it)) }
            Spacer(Modifier.height(6.dp))
            Chips(listOf(0, 1, 2, 3, 5, 10), s.clockIncrement, { "+$it s" }) { vm.updateSettings(s.copy(clockIncrement = it)) }
            SectionTitle("LANGUAGE")
            Chips(listOf("English"), s.language, { it }) { vm.updateSettings(s.copy(language = it)) }
            Text("English is the only language in this version.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
        }
    }
}

private class Lesson(val title: String, val text: String, val fen: String?)
private val lessons = listOf(
    Lesson("The chessboard", "Chess is played on an 8×8 board of 64 squares. Files are the columns a–h, ranks are the rows 1–8. Each player starts with 16 pieces; White moves first. The bottom-right square is always light.", Position.START),
    Lesson("Pawn", "Pawns move one square forward (two from their starting square) but capture one square diagonally forward. Tap the pawn to see its moves.", "8/8/8/8/8/3p1p2/4P3/8 w - - 0 1"),
    Lesson("Knight", "Knights move in an L-shape: two squares one way and one square at a right angle. They are the only pieces that can jump over others.", "8/8/8/8/3N4/8/8/8 w - - 0 1"),
    Lesson("Bishop", "Bishops move any number of squares diagonally and always stay on the same colour of square.", "8/8/8/8/3B4/8/8/8 w - - 0 1"),
    Lesson("Rook", "Rooks move any number of squares horizontally or vertically.", "8/8/8/8/3R4/8/8/8 w - - 0 1"),
    Lesson("Queen", "The queen combines the power of the rook and the bishop.", "8/8/8/8/3Q4/8/8/8 w - - 0 1"),
    Lesson("King", "The king moves one square in any direction. It may never move into check. Protecting your king is the goal of the game.", "8/8/8/8/3K4/8/8/8 w - - 0 1"),
    Lesson("Castling", "Once per game the king can move two squares toward a rook, and the rook jumps to the other side. Neither piece may have moved, the squares between must be empty, and the king may not be in check, pass through check, or land in check. Tap the white king.", "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"),
    Lesson("En passant", "If a pawn advances two squares and lands beside an enemy pawn, that pawn may capture it as if it had moved only one square — but only on the very next move. Tap the white pawn.", "4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1"),
    Lesson("Pawn promotion", "A pawn reaching the far rank must become a queen, rook, bishop or knight (your choice). Tap the pawn, then its destination.", "7k/4P3/8/8/8/8/8/4K3 w - - 0 1"),
    Lesson("Check and checkmate", "A king under attack is in check and the player must respond: move the king, block, or capture the attacker. If there is no legal answer it is checkmate and the game is lost. Here the White rook can deliver checkmate on a8.", "6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1"),
    Lesson("Stalemate", "If the player to move is not in check but has no legal move, the game is a draw by stalemate. In this position Black (to move) is stalemated.", "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1"),
    Lesson("Draw rules", "A game is drawn by: stalemate; insufficient material (e.g. king vs king, or king and a single minor piece vs king); threefold repetition of a position; the fifty-move rule (50 moves by each side with no pawn move or capture); and automatically at fivefold repetition or seventy-five moves. CHESS ARENA applies the threefold and fifty-move draws automatically. A draw can also be agreed.", null)
)

@Composable
private fun LessonBoard(fen: String, boardTheme: Int, pieceTheme: Int) {
    val pos = remember(fen) { Position.fromFen(fen) }
    var sel by remember(fen) { mutableIntStateOf(-1) }
    val legal = remember(fen) { pos.legalMoves() }
    BoardView(pos, Modifier.fillMaxWidth(0.8f).clip(RoundedCornerShape(6.dp)), boardTheme = boardTheme, pieceTheme = pieceTheme, selected = sel,
        targets = legal.filter { it.from == sel }.map { it.to }.toSet(), animMs = 0) { sq -> sel = if (legal.any { it.from == sq }) sq else -1 }
}

@Composable
fun LearnScreen(vm: AppViewModel) {
    val s = vm.settings.collectAsState().value
    Frame("Chess Rules", { vm.back() }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(lessons) { l ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(l.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        Text(l.text, fontSize = 14.sp, modifier = Modifier.fillMaxWidth())
                        l.fen?.let { Spacer(Modifier.height(10.dp)); LessonBoard(it, s.boardTheme, s.pieceTheme) }
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun AboutScreen(vm: AppViewModel) {
    Frame("About", { vm.back() }) { pad ->
        Column(Modifier.padding(pad).padding(20.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo_badge), null, Modifier.size(140.dp))
            Text("CHESS ARENA", fontSize = 26.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Text("Version 1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Text("Works fully offline. No account, no ads, no tracking and no special permissions (only vibration for optional haptics). Games and statistics are stored only on your device.", textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Text("The computer opponent is a built-in alpha-beta search engine written for this app (not Stockfish).", textAlign = TextAlign.Center, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Text("Open-source libraries: AndroidX, Jetpack Compose, Material 3, Room, DataStore, Kotlin Coroutines — Apache License 2.0.", textAlign = TextAlign.Center, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
