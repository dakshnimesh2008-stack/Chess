package com.chessarena.game

import android.app.Application
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chessarena.game.chess.*
import com.chessarena.game.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.abs

sealed class Screen {
    object Home : Screen(); object Setup : Screen(); object Game : Screen(); object History : Screen()
    data class Detail(val id: Long) : Screen(); object Stats : Screen(); object Settings : Screen(); object Learn : Screen(); object About : Screen()
}

enum class Mode { COMPUTER, LOCAL }

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val dao = AppDb.get(app).games()
    val settings: StateFlow<Settings> = repo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val games: StateFlow<List<GameEntity>> = dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun updateSettings(s: Settings) { viewModelScope.launch { repo.save(s) } }

    // ---- navigation ----
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val screen: Screen get() = stack.last()
    fun go(s: Screen) { stack.add(s) }
    fun back(): Boolean { if (stack.size > 1) { stack.removeAt(stack.size - 1); return true }; return false }
    fun home() { stack.clear(); stack.add(Screen.Home) }

    // ---- game session ----
    var mode by mutableStateOf(Mode.COMPUTER); private set
    var playerWhite by mutableStateOf(true); private set
    var difficulty by mutableStateOf(Difficulty.MEDIUM); private set
    var clockSec by mutableIntStateOf(0); private set
    var incSec by mutableIntStateOf(0); private set

    var game by mutableStateOf(ChessGame()); private set
    var version by mutableIntStateOf(0); private set       // bump to refresh UI
    var selected by mutableIntStateOf(-1); private set
    var targets by mutableStateOf<List<Move>>(emptyList()); private set
    var promoChoices by mutableStateOf<List<Move>?>(null); private set
    var thinking by mutableStateOf(false); private set
    var flipped by mutableStateOf(false)
    var whiteMs by mutableLongStateOf(0L); private set
    var blackMs by mutableLongStateOf(0L); private set
    var outcome by mutableStateOf(Outcome.ONGOING); private set
    var winnerWhite by mutableStateOf<Boolean?>(null); private set
    var showResult by mutableStateOf(false)
    var durationSec by mutableIntStateOf(0); private set
    var engineError by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)

    private var token = 0
    private var engineJob: Job? = null
    private var clockJob: Job? = null
    private var paused = false
    private var startElapsed = 0L
    private var saved = false
    private var engine = SearchEngine()
    private var tone: ToneGenerator? = null

    val clockEnabled get() = clockSec > 0
    val over get() = outcome != Outcome.ONGOING
    val engineWhite get() = !playerWhite
    private fun engineToMove() = mode == Mode.COMPUTER && !over && game.pos.white == engineWhite

    fun startGame(m: Mode, white: Boolean, d: Difficulty, minutes: Int, inc: Int) {
        engineJob?.cancel(); engine.cancelled = true; token++
        mode = m; playerWhite = white; difficulty = d; clockSec = minutes * 60; incSec = inc
        game = ChessGame(); selected = -1; targets = emptyList(); promoChoices = null; thinking = false
        outcome = Outcome.ONGOING; winnerWhite = null; showResult = false; saved = false; engineError = null
        whiteMs = clockSec * 1000L; blackMs = clockSec * 1000L
        flipped = m == Mode.COMPUTER && !white
        startElapsed = SystemClock.elapsedRealtime(); paused = false
        version++
        startClock()
        if (engineToMove()) runEngine()
    }

    fun rematch() { startGame(mode, if (mode == Mode.COMPUTER) !playerWhite else true, difficulty, clockSec / 60, incSec) }
    fun restart() { startGame(mode, playerWhite, difficulty, clockSec / 60, incSec) }

    var pendingMode by mutableStateOf(Mode.COMPUTER)

    // ---- input ----
    fun tap(sq: Int) {
        if (over || thinking || promoChoices != null) return
        if (mode == Mode.COMPUTER && game.pos.white != playerWhite) return
        val p = game.pos
        val mv = targets.filter { it.to == sq }
        if (selected >= 0 && mv.isNotEmpty()) {
            if (mv.size > 1) { promoChoices = mv; return }
            commit(mv[0]); return
        }
        val piece = p.b[sq]
        if (piece != 0 && (piece > 0) == p.white) {
            selected = sq; targets = game.legalFrom(sq); sound(0)
        } else { selected = -1; targets = emptyList() }
    }

    fun choosePromotion(piece: Int) { val m = promoChoices?.firstOrNull { it.promo == piece } ?: return; promoChoices = null; commit(m) }
    fun cancelPromotion() { promoChoices = null }

    private fun commit(m: Move) {
        val cap = game.pos.isCapture(m)
        val mover = game.pos.white
        if (!game.play(m)) return
        selected = -1; targets = emptyList()
        if (clockEnabled) { if (mover) whiteMs += incSec * 1000L else blackMs += incSec * 1000L }
        afterMove(cap)
    }

    private fun afterMove(cap: Boolean) {
        version++
        val st = game.status()
        val s = game.sans.lastOrNull() ?: ""
        if (st != Outcome.ONGOING) {
            finish(st, if (st == Outcome.CHECKMATE) !game.pos.white else null)
            return
        }
        sound(if (s.endsWith("+")) 3 else if (cap) 2 else 1)
        if (engineToMove()) runEngine()
    }

    private fun runEngine() {
        val t = ++token; thinking = true
        val pos = game.pos; val hist = game.sans.toList(); val d = difficulty
        engineJob = viewModelScope.launch {
            val started = SystemClock.elapsedRealtime()
            val eng = SearchEngine(); engine = eng
            val mv = try { withContext(Dispatchers.Default) { eng.bestMove(pos, hist, d) } } catch (e: Throwable) { null }
            val wait = 450L - (SystemClock.elapsedRealtime() - started); if (wait > 0) delay(wait)
            if (t != token || over) return@launch
            thinking = false
            if (mv == null) { engineError = "The computer could not find a move."; return@launch }
            while (paused && isActive) delay(100)
            if (t != token || over) return@launch
            val cap = game.pos.isCapture(mv); val mover = game.pos.white
            if (game.play(mv)) {
                if (clockEnabled) { if (mover) whiteMs += incSec * 1000L else blackMs += incSec * 1000L }
                afterMove(cap)
            } else engineError = "The computer produced an invalid move."
        }
    }

    // ---- controls ----
    fun undo() {
        if (game.moves.isEmpty() || outcome == Outcome.TIMEOUT) return
        engineJob?.cancel(); engine.cancelled = true; token++; thinking = false; promoChoices = null
        if (mode == Mode.COMPUTER) {
            do { game.undo() } while (game.moves.isNotEmpty() && game.pos.white != playerWhite)
        } else game.undo()
        outcome = Outcome.ONGOING; winnerWhite = null; showResult = false; saved = false
        selected = -1; targets = emptyList(); version++
        startClock()
        if (engineToMove()) runEngine()
    }

    fun resign() {
        if (over) return
        val loserWhite = if (mode == Mode.COMPUTER) playerWhite else game.pos.white
        finish(Outcome.RESIGN, !loserWhite)
    }

    /** Computer accepts a draw only after move 20 and if it is not clearly better. */
    fun offerDraw(): Boolean {
        if (over) return false
        if (mode == Mode.LOCAL) { finish(Outcome.AGREED_DRAW, null); return true }
        val diff = material(game.pos, engineWhite) - material(game.pos, playerWhite)
        val ok = game.moves.size >= 40 && diff <= 100
        if (ok) finish(Outcome.AGREED_DRAW, null) else message = "The computer declined the draw offer."
        return ok
    }

    private fun material(p: Position, w: Boolean): Int {
        val v = intArrayOf(0, 100, 320, 330, 500, 900, 0); var s = 0
        for (x in p.b) if (x != 0 && (x > 0) == w) s += v[abs(x)]
        return s
    }

    private fun finish(o: Outcome, winW: Boolean?) {
        if (over) return
        engineJob?.cancel(); engine.cancelled = true; token++; thinking = false; clockJob?.cancel()
        durationSec = ((SystemClock.elapsedRealtime() - startElapsed) / 1000).toInt()
        outcome = o; winnerWhite = winW; showResult = true; selected = -1; targets = emptyList()
        sound(if (o == Outcome.CHECKMATE) 4 else 5)
        save()
    }

    private fun save() {
        if (saved) return; saved = true
        val dur = durationSec
        val w = winnerWhite
        val result = if (mode == Mode.COMPUTER) (if (w == null) "DRAW" else if (w == playerWhite) "WIN" else "LOSS")
                     else (if (w == null) "DRAW" else if (w) "WHITE" else "BLACK")
        val e = GameEntity(date = System.currentTimeMillis(), mode = mode.name, difficulty = if (mode == Mode.COMPUTER) difficulty.label else "-",
            result = result, reason = outcome.name, playerWhite = playerWhite, moveCount = game.moves.size, durationSec = dur,
            uci = game.moves.joinToString(" ") { it.uci() }, sanText = game.sans.joinToString(" "))
        viewModelScope.launch { dao.insert(e) }
    }

    // ---- clock ----
    private fun startClock() {
        clockJob?.cancel()
        if (!clockEnabled) return
        clockJob = viewModelScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (isActive && !over) {
                delay(100)
                val now = SystemClock.elapsedRealtime(); val dt = now - last; last = now
                if (paused || game.moves.isEmpty()) continue
                if (game.pos.white) whiteMs -= dt else blackMs -= dt
                if (whiteMs <= 0 || blackMs <= 0) {
                    val whiteLost = whiteMs <= 0
                    if (whiteLost) whiteMs = 0 else blackMs = 0
                    val opp = !whiteLost
                    val survivorCanMate = canMate(game.pos, opp)
                    finish(Outcome.TIMEOUT, if (survivorCanMate) opp else null)
                }
            }
        }
    }

    private fun canMate(p: Position, w: Boolean): Boolean {
        var minors = 0
        for (x in p.b) if (x != 0 && (x > 0) == w) { val t = abs(x); if (t == PAWN || t == ROOK || t == QUEEN) return true; if (t == KNIGHT || t == BISHOP) minors++ }
        return minors >= 2
    }

    fun onPause() { paused = true }
    fun onResume() { paused = false }

    // ---- feedback ----
    private fun sound(kind: Int) {
        val s = settings.value
        if (s.sound) try {
            val tg = tone ?: ToneGenerator(AudioManager.STREAM_MUSIC, 60).also { tone = it }
            when (kind) { 0 -> tg.startTone(ToneGenerator.TONE_PROP_BEEP, 40); 1 -> tg.startTone(ToneGenerator.TONE_DTMF_1, 60)
                2 -> tg.startTone(ToneGenerator.TONE_DTMF_9, 110); 3 -> tg.startTone(ToneGenerator.TONE_PROP_ACK, 160)
                4 -> tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400); else -> tg.startTone(ToneGenerator.TONE_PROP_PROMPT, 250) }
        } catch (_: Throwable) {}
        if (s.vibration && kind >= 1) try {
            @Suppress("DEPRECATION") val v = getApplication<Application>().getSystemService(android.content.Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(if (kind >= 4) 120 else 25, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Throwable) {}
    }

    fun clearHistory() { viewModelScope.launch { dao.clear() } }
    suspend fun gameById(id: Long) = dao.byId(id)

    override fun onCleared() { engine.cancelled = true; tone?.release(); super.onCleared() }
}
