# Third-party notices

CHESS ARENA uses these open-source libraries, all licensed under the Apache License 2.0
(https://www.apache.org/licenses/LICENSE-2.0):

- AndroidX (Core, Activity, Lifecycle, Room, DataStore)
- Jetpack Compose and Material 3
- Kotlin and kotlinx.coroutines

The chess rules and the computer opponent (alpha-beta search) are original code written for this project.
**Stockfish is NOT included.** If you later bundle Stockfish, it is licensed under GPLv3 and the
whole app would need to comply with that license (source offer, license text).
