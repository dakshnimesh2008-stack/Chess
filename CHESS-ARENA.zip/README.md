# CHESS ARENA

Offline Android chess game — Kotlin, Jetpack Compose, Material 3, Room, DataStore, MVVM.
Package: `com.chessarena.game` · minSdk 26 · targetSdk 34.

## Build the APK with GitHub Actions (no Android Studio needed)

> GitHub's website does **not** extract ZIP files. Extract this ZIP on your phone/PC first, then upload the *contents*.

1. Create a new GitHub repository.
2. Extract `CHESS-ARENA.zip`. You should see `app/`, `build.gradle.kts`, `settings.gradle.kts`, `.github/` … directly inside (no extra parent folder).
3. On the repo page: **Add file → Upload files**, drag in **all** extracted items — including the hidden `.github` folder (it contains `workflows/build.yml`). Commit.
   If `.github` cannot be uploaded (some phone file managers hide it): **Add file → Create new file**, name it `.github/workflows/build.yml`, and paste the workflow text.
4. Open the **Actions** tab → *Build CHESS ARENA* (it runs on every push; or use **Run workflow**).
5. When it finishes, open the run and download the artifact **CHESS-ARENA-debug-apk** (`app-debug.apk`).

The workflow runs the unit tests first (`gradle testDebugUnitTest`), then `gradle assembleDebug`.
It uses Gradle 8.7 installed by `gradle/actions/setup-gradle`, so no `gradlew`/wrapper jar is required.
(Android Studio users: open the folder; run `gradle wrapper` if you want a wrapper.)

## Optional signed release APK
Add these repository secrets (Settings → Secrets and variables → Actions): `KEYSTORE_BASE64` (base64 of your .jks),
`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. The workflow then also builds and uploads `app-release.apk`.
No credentials are included in this project.

## Features
Play vs computer (6 levels, choose colour/random), local multiplayer, full chess rules (castling, en passant, promotion,
check/checkmate/stalemate, insufficient material, threefold/fivefold, 50/75-move), SAN move list, chess clock with
increment, undo, flip, resign, draw offer, history with replay, statistics (Room), settings (DataStore),
5 board themes, 3 piece styles (vector-drawn pieces), rules/learning section with interactive diagrams.

## Known limitations (please read)
- **This code was written without being compiled or run** (no Android SDK/network in the authoring environment). Expect that the first
  GitHub Actions run may report a compile error or a failing unit test; paste the log and it can be fixed quickly.
- **Stockfish is not integrated.** The opponent is a built-in alpha-beta engine (`chess/Engine.kt`, behind an `Engine` interface),
  roughly club-level at best. Stockfish needs native binaries/NDK and GPL compliance.
- Drag-and-drop is not implemented (tap to select, tap to move). Only the last move is animated.
- Games in progress are kept while the app is alive but are not restored after the app process is killed.
- Threefold repetition and the fifty-move rule end the game automatically (no claim step).
- Sound uses system tones (no audio asset files). Only English is available. Portrait only.
- Accuracy is not shown (no real analysis is computed).
